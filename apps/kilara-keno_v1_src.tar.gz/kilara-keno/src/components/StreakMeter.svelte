<script lang="ts">
	import { stateI18nDerived } from 'state-shared';

	import config from '../game/config';
	import { ladderMultiplier } from '../game/keno';
	import { getContext } from '../game/context';

	// The streak multiplier's ladder: one step per level, the current level filled, every step up
	// to the best level reached tinted and the best one marked in the win colour, the multiplier
	// the round will use at the end. Above the top step the level still counts, the multiplier
	// stays at the top.
	const context = getContext();
	const round = $derived(context.stateGame.round);
	const current = $derived(Math.min(round?.current ?? 0, config.ladder.length));
	const best = $derived(Math.min(round?.best ?? 0, config.ladder.length));
	const multiplier = $derived(ladderMultiplier(round?.best ?? 0));
</script>

<div
	class="meter"
	data-test="streak-meter"
	data-current={round?.current ?? 0}
	data-best={round?.best ?? 0}
>
	<span class="label">{stateI18nDerived.translate('STREAK')}</span>
	<ol class="steps">
		{#each config.ladder as step, index}
			{@const level = index + 1}
			<li
				class:reached={level <= best}
				class:current={level === current}
				class:best={level === best}
			>
				×{step}
			</li>
		{/each}
	</ol>
	<span class="total" class:up={multiplier > 1}>×{multiplier}</span>
</div>

<style lang="scss">
	.meter {
		display: flex;
		align-items: center;
		gap: 0.6em;
		height: 100%;
	}

	.label {
		flex: none;
		color: var(--keno-muted);
		font-size: 0.9em;
		font-weight: 700;
		letter-spacing: 0.1em;
	}

	.steps {
		flex: 1;
		display: grid;
		grid-template-columns: repeat(7, minmax(0, 1fr));
		gap: 0.25em;
		height: 100%;
		margin: 0;
		padding: 0;
		list-style: none;
	}

	li {
		position: relative;
		display: grid;
		place-items: center;
		background-color: var(--keno-tile);
		color: var(--keno-muted);
		font-size: 1.05em;
		font-weight: 700;
		font-variant-numeric: tabular-nums;
		transition:
			background-color 0.15s,
			color 0.15s;

		&.reached {
			background-color: var(--keno-tile-hover);
			color: var(--keno-text);
		}

		&.current {
			background-color: var(--keno-text);
			color: var(--keno-dark);
		}

		/* the best level reached: a solid bar in the win colour under its step */
		&.best::after {
			content: '';
			position: absolute;
			left: 0;
			right: 0;
			bottom: 0;
			height: 0.28em;
			background-color: var(--keno-win);
		}
	}

	.total {
		flex: none;
		min-width: 2.6em;
		color: var(--keno-muted);
		font-size: 1.35em;
		font-weight: 800;
		font-variant-numeric: tabular-nums;
		text-align: right;

		&.up {
			color: var(--keno-win);
		}
	}
</style>

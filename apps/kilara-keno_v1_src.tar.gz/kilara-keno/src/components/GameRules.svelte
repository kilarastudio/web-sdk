<script lang="ts">
	import { stateI18nDerived, stateUrlDerived } from 'state-shared';
	import { UiInfoSection, i18nDerived } from 'components-ui-html';

	import config from '../game/config';
	import { modeTitle, stakeWord } from '../game/betModeMeta';
	import type { ModeName } from '../game/keno';

	// The rules, as the math implements them (math-sdk/games/kilara_keno/readme.txt). Costs, the
	// top prizes, the return and the ladder come from the game's config, not from this text.
	const t = stateI18nDerived.translate;
	const social = stateUrlDerived.social();
	const amount = stakeWord(social);
	const { times, percent } = stateI18nDerived;
	const ladder = config.ladder
		.map((step, index) =>
			index === config.ladder.length - 1
				? `${index + 1}+: ${times(step)}`
				: `${index + 1}: ${times(step)}`,
		)
		.join(', ');
	// a mode is named as the math and the replay name it (Engine wants one name everywhere)
	const modes = Object.entries(config.betModes).map(([name, mode]) => ({
		name: name as ModeName,
		title: modeTitle(name),
		...mode,
	}));

	const sections = [
		{
			title: t('HOW TO PLAY'),
			lines: [
				t(
					'The board has 40 numbers. Before a round choose how many numbers to play (3, 5, 8 or 10), a level (LOW, MID, HIGH or CHAIN) and your numbers; QUICK PICK fills the numbers still open at random.',
				),
				t(
					'LOW, MID and HIGH draw 10 numbers, one at a time, without repeats. CHAIN draws 12. A drawn number you chose is a hit.',
				),
				t(
					'Win = the value for your number of hits ({table}) × the streak multiplier. Values are multiples of the base {amount}.',
					{ amount, table: i18nDerived.payTable() },
				),
			],
		},
		{
			title: t('STREAK MULTIPLIER'),
			lines: [
				t(
					'LOW, MID and HIGH: the streak level is the run of hits drawn one after another; a miss ends the run. The longest run of the round sets the multiplier.',
				),
				t('Multiplier per level: {ladder}. A round with no hit, or one hit, has ×1.', { ladder }),
			],
		},
		{
			title: 'CHAIN',
			lines: [
				t(
					'CHAIN draws 12 numbers instead of 10. A hit raises the streak level by one; a miss lowers it by one, never below zero. The highest level reached sets the multiplier, on the same ladder.',
				),
				social
					? t('CHAIN can be played for {cost} the play amount and has its own win table.', {
							cost: times(config.levelCost.chain),
						})
					: t('CHAIN costs {cost} the {amount} and has its own win table.', {
							cost: times(config.levelCost.chain),
							amount,
						}),
				t('CHAIN is switched on with a confirmation and stays on until you choose another level.'),
			],
		},
	];

	const general = [
		t('The highest win is {max} the base {amount}.', { max: times(config.wincap), amount }),
		t(
			"The draw is decided by the game server. Your numbers stand in for the ones the server played: hits, their order and the win are the server's.",
		),
		t(
			'A replay, or a round resumed after a reload, shows the round with the numbers the server played, which can differ from the numbers chosen. Hits, their order, the multiplier and the win are the same.',
		),
		t('Malfunction voids all wins and plays.'),
	];
</script>

{#each sections as section}
	<UiInfoSection title={section.title}>
		{#each section.lines as line}
			<p>{line}</p>
		{/each}
	</UiInfoSection>
{/each}

<UiInfoSection title={t('MODES')}>
	<table>
		<thead>
			<tr>
				<th>{t('MODE')}</th>
				<th>{social ? t('PLAY') : t('COST')}</th>
				<th>{t('DRAWN')}</th>
				<th>{t('RTP')}</th>
				<th>{t('MAX WIN')}</th>
			</tr>
		</thead>
		<tbody>
			{#each modes as mode}
				<tr data-mode={mode.name}>
					<td>{mode.title}</td>
					<td>{times(mode.cost)}</td>
					<td>{mode.draws}</td>
					<td>{percent(mode.rtp)}</td>
					<td>{times(mode.maxWin)}</td>
				</tr>
			{/each}
		</tbody>
	</table>
</UiInfoSection>

<UiInfoSection title={t('GENERAL')}>
	{#each general as line}
		<p>{line}</p>
	{/each}
</UiInfoSection>

<style lang="scss">
	table {
		width: 100%;
		border-collapse: collapse;
		font-variant-numeric: tabular-nums;
	}

	th {
		color: var(--ui-text-muted);
		font-size: 0.75em;
		font-weight: 600;
		letter-spacing: 0.1em;
		text-align: left;
	}

	th,
	td {
		padding: 0.3em 0.6em 0.3em 0;
	}

	td:first-child {
		color: var(--ui-text);
		font-weight: 700;
	}

	tbody tr + tr td {
		border-top: 1px solid rgba(255, 255, 255, 0.08);
	}
</style>

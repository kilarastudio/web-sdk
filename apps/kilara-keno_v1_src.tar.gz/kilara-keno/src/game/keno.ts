import _ from 'lodash';

import config from './config';

// The rules the frontend needs, as math-sdk/games/kilara_keno/readme.txt states them. Nothing
// here decides an outcome: the books do. This only names modes, relabels a book's board onto the
// player's numbers and replays the streak meter from a book's hit/miss order.

export type Level = (typeof config.levels)[number];
export type Picks = (typeof config.pickSizes)[number];
export type ModeName = keyof typeof config.betModes;

export const NUMBERS = _.range(1, config.boardNumbers + 1);

export const modeName = (level: Level, picks: Picks) => `${level}_${picks}` as ModeName;

export const parseMode = (key: string): { level: Level; picks: Picks } | null => {
	const mode = config.betModes[key.toLowerCase() as ModeName];
	return mode ? { level: mode.level as Level, picks: mode.picks as Picks } : null;
};

export const isChain = (level: Level) => level === config.chainLevel;

// The multiplier of a streak level: level 0 and 1 are ×1, every level above the ladder's top
// pays the top.
export const ladderMultiplier = (level: number) =>
	level < 1 ? 1 : config.ladder[Math.min(level, config.ladder.length) - 1];

// Live play: the player's numbers stand in for the book's. The i-th smallest of the book's
// "selected" becomes the player's i-th smallest pick, and the i-th smallest of the book's other
// numbers the i-th smallest number the player did not pick. A relabelling of the board: the
// hit/miss order, hits and win are the book's.
export const relabel = (
	book: { selected: number[]; numbers: number[] },
	picked: number[],
): { selected: number[]; numbers: number[] } => {
	const bookSelected = _.sortBy(book.selected);
	const playerSelected = _.sortBy(picked);
	if (bookSelected.length !== playerSelected.length) {
		throw new Error(`relabel: the book picks ${bookSelected.length}, the player ${picked.length}`);
	}
	const bookOther = NUMBERS.filter((n) => !bookSelected.includes(n));
	const playerOther = NUMBERS.filter((n) => !playerSelected.includes(n));
	const map = new Map<number, number>([
		...bookSelected.map((n, i) => [n, playerSelected[i]] as const),
		...bookOther.map((n, i) => [n, playerOther[i]] as const),
	]);

	return { selected: playerSelected, numbers: book.numbers.map((n) => map.get(n)!) };
};

// The streak meter after each draw, from the round's hit/miss order. Low, Mid and High: the level
// is the current run of hits, a miss resets it. Chain: a hit raises the level by one, a miss
// lowers it by one, never below zero. The best level reached sets the multiplier.
export const streakSteps = (level: Level, pattern: number[]) => {
	let current = 0;
	let best = 0;
	let hits = 0;

	return pattern.map((hit) => {
		if (hit) {
			hits += 1;
			current += 1;
		} else {
			current = isChain(level) ? Math.max(0, current - 1) : 0;
		}
		best = Math.max(best, current);
		return { hits, current, best };
	});
};

// Fills the slots left with numbers the player has not picked; with no slot left, a fresh set.
// This chooses numbers to play, not an outcome, so it may be random.
export const quickPick = (picked: number[], picks: number) => {
	const keep = picked.length >= picks ? [] : picked;
	const free = _.shuffle(NUMBERS.filter((n) => !keep.includes(n)));
	return [...keep, ...free.slice(0, picks - keep.length)];
};
